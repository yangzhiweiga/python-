# -*- coding:utf-8 -*-
def receive():
    print("receive")
