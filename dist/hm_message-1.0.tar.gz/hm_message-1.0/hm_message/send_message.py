# -*- coding:utf-8 -*-
def send():
    print("send")